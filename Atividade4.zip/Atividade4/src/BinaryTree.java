// Classe para a lógica de negócio da árvore

import javax.swing.JOptionPane;

class BinaryTree {
    Node root;

    public BinaryTree() {
        root = null;
    }

    // Método para adicionar um nó à árvore
    private Node addNode(Node node, int data) {
        if (node == null) {
            return new Node(data);
        }

        if (data < node.data) {
            node.left = addNode(node.left, data);
        } else if (data > node.data) {
            node.right = addNode(node.right, data);
        }

        return node;
    }

    // Método para adicionar um valor à árvore
    public void add(int data) {
        root = addNode(root, data);
    }

    // Método para percorrer a árvore em pré-ordem
    private void preOrderTraversal(Node node) {
        if (node != null) {
            JOptionPane.showMessageDialog(null, node.data);
            preOrderTraversal(node.left);
            preOrderTraversal(node.right);
        }
    }

    // Método para iniciar a travessia em pré-ordem
    public void preOrder() {
        preOrderTraversal(root);
    }
}

