// Classe que interage com o usuário

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        // Adicionando valores à árvore
        tree.add(50);
        tree.add(30);
        tree.add(20);
        tree.add(40);
        tree.add(70);
        tree.add(60);
        tree.add(80);

        // Exibindo a travessia em pré-ordem usando JOptionPane
        JOptionPane.showMessageDialog(null, "Travessia em pré-ordem:");
        tree.preOrder();
    }
}
